package resena;

import usuario.Usuario;

public class Resena {
    private Usuario autor; // Autor de la reseña (puede ser un estudiante o un profesor)
    private String contenido; // Contenido de la reseña
    private int calificacion; // Calificación del Learning Path o actividad, de 1 a 5

    // Constructor
    public Resena(Usuario autor, String contenido, int calificacion) {
        this.autor = autor;
        this.contenido = contenido;
        setCalificacion(calificacion); // Usar el setter para asignar la calificación
    }

    // Getters y setters
    public Usuario getAutor() {
        return autor;
    }

    public void setAutor(Usuario autor) {
        this.autor = autor;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        if (calificacion < 1 || calificacion > 5) {
            System.out.println("Calificación no válida. Se asignará una calificación predeterminada de 3.");
            this.calificacion = 3; // Calificación predeterminada si el valor proporcionado no es válido
        } else {
            this.calificacion = calificacion;
        }
    }

    // Método para mostrar la reseña
    public String mostrarResena() {
        return "Autor: " + autor.getUsername() + "\nCalificación: " + calificacion + "\nContenido: " + contenido;
    }
}
