package registro;

import java.util.HashMap;
import java.util.Map;

import usuario.Estudiante;
import usuario.Profesor;
import usuario.Usuario;

public class Registro {
    // Un mapa que almacena los usuarios registrados, con el nombre de usuario como clave
    private Map<String, Usuario> usuariosRegistrados;

    // Constructor
    public Registro() {
        usuariosRegistrados = new HashMap<>();
    }

    // metodo para registrar un nuevo usuario
    public Usuario registrarUsuario(String nombre, String apellido, String username, String password, String correo, boolean esProfesor) {
        if (usuariosRegistrados.containsKey(username)) {
            System.out.println("Error: El nombre de usuario ya existe. Por favor, elige otro.");
            return null;
        }

        if (!esPasswordValida(password)) {
            System.out.println("Error: La contraseña debe tener al menos 8 caracteres y contener al menos 3 números.");
            return null;
        }

        Usuario nuevoUsuario;
        if (esProfesor) {
            nuevoUsuario = new Profesor(nombre, apellido, username, password);
        } else {
            nuevoUsuario = new Estudiante(nombre, apellido, username, password);
        }

        usuariosRegistrados.put(username, nuevoUsuario);
        System.out.println("Usuario registrado exitosamente: " + username);
        return nuevoUsuario;
    }

    // metodo para verificar si un nombre de usuario ya está registrado
    public boolean usuarioExiste(String username) {
        return usuariosRegistrados.containsKey(username);
    }

    // metodo para validar una contraseña (debe tener al menos 8 caracteres y 3 números)
    private boolean esPasswordValida(String password) {
        if (password.length() < 8) {
            return false;
        }

        int contadorNumeros = 0;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                contadorNumeros++;
            }
        }
        return contadorNumeros >= 3;
    }

    // metodo para establecer un nuevo nombre de usuario si está disponible
    public boolean establecerNombreDeUsuario(String usernameAntiguo, String usernameNuevo) {
        if (!usuariosRegistrados.containsKey(usernameAntiguo)) {
            System.out.println("Error: No se encontró el usuario con el nombre actual.");
            return false;
        }

        if (usuariosRegistrados.containsKey(usernameNuevo)) {
            System.out.println("Error: El nombre de usuario nuevo ya está en uso.");
            return false;
        }

        Usuario usuario = usuariosRegistrados.remove(usernameAntiguo);
        usuario.setUsername(usernameNuevo);
        usuariosRegistrados.put(usernameNuevo, usuario);
        System.out.println("Nombre de usuario actualizado exitosamente a: " + usernameNuevo);
        return true;
    }

    // metodo para verificar si una contraseña es válida
    public boolean verificarContraseña(String password) {
        return esPasswordValida(password);
    }

    // metodo para buscar un usuario registrado por nombre de usuario
    public Usuario buscarUsuario(String username) {
        return usuariosRegistrados.get(username);
    }
}
