package learningpath;
public class Tarea extends Actividad {

    public Tarea(String descripcion, int duracion, int nivelDificultad) {
        super(descripcion, duracion, nivelDificultad);
    }
    // meotodo para completar la tarea
    @Override
    public void completar() {
        System.out.println("Realizando la tarea: " + descripcion);
        marcarCompletada(); 
    }
}