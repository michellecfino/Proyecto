package learningpath;
import resena.Resena;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LearningPath {
    private String titulo;
    private String descripcion;
    private String objetivo;
    private int nivelDificultad; 
    private int duracion; // duracion total en minutos (calculada)
    private double rating; // Rating promedio del Learning Path
    private Date fechaCreacion;
    private Date fechaModificacion;
    private int version;
    private List<Actividad> actividades; // Lista de actividades que forman el Learning Path
    private List<Resena> resenas; // Lista de reseñas asociadas al Learning Path

    // Constructor
    public LearningPath(String titulo, String descripcion, String objetivo, int nivelDificultad) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.objetivo = objetivo;
        this.nivelDificultad = nivelDificultad;
        this.duracion = 0;
        this.rating = 0.0;
        this.fechaCreacion = new Date();
        this.fechaModificacion = new Date();
        this.version = 1;
        this.actividades = new ArrayList<>();
        this.resenas = new ArrayList<>();
    }

    // metodo para agregar una actividad al Learning Path
    public void agregarActividad(Actividad actividad) {
        actividades.add(actividad);
        duracion += actividad.getDuracion();
        fechaModificacion = new Date();
        version++;
        System.out.println("Actividad añadida al Learning Path: " + actividad.getDescripcion());
    }

    // metodo para eliminar una actividad del Learning Path
    public void eliminarActividad(Actividad actividad) {
        if (actividades.remove(actividad)) {
            duracion -= actividad.getDuracion();
            fechaModificacion = new Date();
            version++;
            System.out.println("Actividad eliminada del Learning Path: " + actividad.getDescripcion());
        }
    }

    // metodo para mostrar la estructura del Learning Path
    public void mostrarEstructura() {
        System.out.println("Actividades en este Learning Path:");
        for (Actividad actividad : actividades) {
            System.out.println("- " + actividad.getDescripcion());
        }
    }

    // metodo para agregar una reseña al Learning Path
    public void agregarResena(Resena resena) {
        resenas.add(resena);
        actualizarRating();
        fechaModificacion = new Date();
        version++;
        System.out.println("Reseña agregada por: " + resena.getAutor().getUsername());
    }

    // metodo para mostrar todas las reseñas del Learning Path
    public void mostrarResenas() {
        System.out.println("Reseñas para el Learning Path: " + titulo);
        for (Resena resena : resenas) {
            System.out.println(resena.mostrarResena());
        }
    }

    // metodo para actualizar el rating promedio
    private void actualizarRating() {
        double totalRating = 0;
        for (Resena resena : resenas) {
            totalRating += resena.getCalificacion();
        }
        this.rating = resenas.size() > 0 ? totalRating / resenas.size() : 0;
    }

    // Getters y Setters
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
        fechaModificacion = new Date();
        version++;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
        fechaModificacion = new Date();
        version++;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
        fechaModificacion = new Date();
        version++;
    }

    public int getNivelDificultad() {
        return nivelDificultad;
    }

    public void setNivelDificultad(int nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
        fechaModificacion = new Date();
        version++;
    }

    public int getDuracion() {
        return duracion;
    }

    public double getRating() {
        return rating;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public int getVersion() {
        return version;
    }

    public List<Actividad> getActividades() {
        return actividades;
    }
}

