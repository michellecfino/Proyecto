package learningpath;

public class Recurso extends Actividad {
    private String tipoRecurso; // Tipo de recurso: Video, Documento, Libro, etc.
    private String url; // URL del recurso si está en línea

    // Constructor
    public Recurso(String descripcion, int duracion, int nivelDificultad, String tipoRecurso, String url) {
        super(descripcion, duracion, nivelDificultad);
        this.tipoRecurso = tipoRecurso;
        this.url = url;
    }

    // Constructor sin URL
    public Recurso(String descripcion, int duracion, int nivelDificultad, String tipoRecurso) {
        this(descripcion, duracion, nivelDificultad, tipoRecurso, null);
    }

    //  tipo de recurso
    public String getTipoRecurso() {
        return tipoRecurso;
    }

    // establecer el tipo de recurso con validacion
    public void setTipoRecurso(String tipoRecurso) {
        if (tipoRecurso == null || tipoRecurso.isEmpty()) {
            throw new IllegalArgumentException("El tipo de recurso no puede estar vacío.");
        }
        this.tipoRecurso = tipoRecurso;
    }

    // obtener la URL del recurso
    public String getUrl() {
        return url;
    }

    // establecer la URL del recurso
    public void setUrl(String url) {
        this.url = url;
    }

    // metodo para completar el recurso
    @Override
    public void completar() {
        System.out.println("Revisando el recurso: " + getDescripcion());
        if (url != null && !url.isEmpty()) {
            System.out.println("Puedes acceder al recurso en: " + url);
        }
        marcarCompletada();
    }
}
