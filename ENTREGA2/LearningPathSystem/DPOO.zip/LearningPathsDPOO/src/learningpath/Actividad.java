package learningpath;
public abstract class Actividad {
    protected String descripcion;
    protected int duracion; 
    protected int nivelDificultad;
    protected boolean completada = false; 
    protected String resultado;

    public Actividad(String descripcion, int duracion, int nivelDificultad) {
        this.descripcion = descripcion;
        this.duracion = duracion;
        this.nivelDificultad = nivelDificultad;
        this.resultado = "No Completada";
    }

    // obtener la descripcion de la actividad
    public String getDescripcion() {
        return descripcion;
    }

    // establecer una nueva descripcion para la actividad
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // obtener la duracion de la actividad
    public int getDuracion() {
        return duracion;
    }

    // establecer una nueva duracion para la actividad
    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    // obtener el nivel de dificultad de la actividad
    public int getNivelDificultad() {
        return nivelDificultad;
    }

    // establecer un nuevo nivel de dificultad
    public void setNivelDificultad(int nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
    }

    // comprobar si la actividad esta completada
    public boolean isCompletada() {
        return completada;
    }

    // marcar la actividad como completada
    protected void marcarCompletada() {
        this.completada = true;
        this.resultado = "Completada";
        System.out.println("Actividad completada: " + descripcion);
    }

    // obtener el resultado de la actividad
    public String getResultado() {
        return resultado;
    }

    // metodo abstracto para completar la actividad
    public abstract void completar();
}
