package learningpath;

import pregunta.PreguntaCerrada;
import java.util.ArrayList;
import java.util.List;

public class Quiz extends Actividad {
    private List<PreguntaCerrada> preguntasCerradas;

    public Quiz(String descripcion, int duracion, int nivelDificultad) {
        super(descripcion, duracion, nivelDificultad);
        this.preguntasCerradas = new ArrayList<>();
    }

    public void agregarPregunta(PreguntaCerrada pregunta) {
        preguntasCerradas.add(pregunta);
    }

    // metodo para obtener la lista de preguntas cerradas del quiz
    public List<PreguntaCerrada> getPreguntas() {
        return preguntasCerradas;
    }

    @Override
    public void completar() {
        System.out.println("Realizando el quiz: " + getDescripcion());
        marcarCompletada();
    }
}

