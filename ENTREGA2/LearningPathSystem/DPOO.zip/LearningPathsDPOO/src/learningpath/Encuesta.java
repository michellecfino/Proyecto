package learningpath;

import pregunta.PreguntaAbierta;
import java.util.ArrayList;
import java.util.List;

public class Encuesta extends Actividad {
    private List<PreguntaAbierta> preguntasAbiertas;

    public Encuesta(String descripcion, int duracion, int nivelDificultad) {
        super(descripcion, duracion, nivelDificultad);
        this.preguntasAbiertas = new ArrayList<>();
    }

    public void agregarPregunta(PreguntaAbierta pregunta) {
        preguntasAbiertas.add(pregunta);
    }

    // metodo para obtener la lista de preguntas abiertas de la encuesta
    public List<PreguntaAbierta> getPreguntas() {
        return preguntasAbiertas;
    }

    @Override
    public void completar() {
        System.out.println("Completando la encuesta: " + getDescripcion());
        marcarCompletada();
    }
}
