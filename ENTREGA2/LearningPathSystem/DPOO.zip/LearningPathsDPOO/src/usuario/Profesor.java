package usuario;

import learningpath.*;
import pregunta.PreguntaAbierta;
import pregunta.PreguntaCerrada;
import resena.Resena;

public class Profesor extends Usuario {

    // Constructor
    public Profesor(String nombre, String apellido, String username, String password) {
        super(nombre, apellido, username, password);
    }

    // metodo para crear un nuevo Learning Path
    public LearningPath crearLearningPath(String titulo, String descripcion, String objetivo, int nivelDificultad) {
        LearningPath nuevoLearningPath = new LearningPath(titulo, descripcion, objetivo, nivelDificultad);
        System.out.println("Learning Path creado: " + titulo);
        return nuevoLearningPath;
    }

    // metodo para agregar una actividad a un Learning Path
    public void agregarActividad(LearningPath learningPath, Actividad actividad) {
        if (learningPath == null || actividad == null) {
            System.out.println("Error: Learning Path o actividad no válidos.");
            return;
        }
        learningPath.agregarActividad(actividad);
        System.out.println("Actividad agregada al Learning Path: " + learningPath.getTitulo());
    }

    // metodo para crear una nueva actividad (recurso, tarea, quiz, examen, encuesta)
    public Actividad crearActividad(String tipo, String descripcion, int duracion, int nivelDificultad) {
        switch (tipo.toLowerCase()) {
            case "recurso":
                return new Recurso(descripcion, duracion, nivelDificultad, "Documento");
            case "tarea":
                return new Tarea(descripcion, duracion, nivelDificultad);
            case "quiz":
                return new Quiz(descripcion, duracion, nivelDificultad);
            case "examen":
                return new Examen(descripcion, duracion, nivelDificultad);
            case "encuesta":
                return new Encuesta(descripcion, duracion, nivelDificultad);
            default:
                System.out.println("Error: Tipo de actividad desconocido.");
                return null; // Si el tipo de actividad no es válido, devuelve null
        }
    }

    // metodo para modificar la información de un Learning Path
    public void modificarLearningPath(LearningPath learningPath, String nuevoTitulo, String nuevaDescripcion, String nuevoObjetivo, int nuevoNivelDificultad) {
        if (learningPath == null) {
            System.out.println("Error: Learning Path no válido.");
            return;
        }
        learningPath.setTitulo(nuevoTitulo);
        learningPath.setDescripcion(nuevaDescripcion);
        learningPath.setObjetivo(nuevoObjetivo);
        learningPath.setNivelDificultad(nuevoNivelDificultad);
        System.out.println("Learning Path modificado: " + nuevoTitulo);
    }

    // metodo para agregar una pregunta abierta a un examen
    public void agregarPreguntaAbierta(Examen examen, PreguntaAbierta pregunta) {
        if (examen == null || pregunta == null) {
            System.out.println("Error: Examen o pregunta no válidos.");
            return;
        }
        examen.agregarPregunta(pregunta);
        System.out.println("Pregunta abierta agregada al examen.");
    }

    // metodo para agregar una pregunta cerrada a un quiz
    public void agregarPreguntaCerrada(Quiz quiz, PreguntaCerrada pregunta) {
        if (quiz == null || pregunta == null) {
            System.out.println("Error: Quiz o pregunta no válidos.");
            return;
        }
        quiz.agregarPregunta(pregunta);
        System.out.println("Pregunta cerrada agregada al quiz.");
    }

    // metodo para calificar una actividad enviada por un estudiante
    public void calificarActividad(Actividad actividad, int calificacion) {
        if (actividad == null || calificacion < 1 || calificacion > 5) {
            System.out.println("Error: Actividad no válida o calificación fuera de rango (1-5).");
            return;
        }
        System.out.println("Calificación de la actividad '" + actividad.getDescripcion() + "': " + calificacion);
    }

    // metodo para clonar un Learning Path
    public LearningPath clonarLearningPath(LearningPath learningPath) {
        if (learningPath == null) {
            System.out.println("Error: Learning Path no válido.");
            return null;
        }

        LearningPath clone = new LearningPath(
                learningPath.getTitulo() + " (Copia)",
                learningPath.getDescripcion(),
                learningPath.getObjetivo(),
                learningPath.getNivelDificultad()
        );

        for (Actividad actividad : learningPath.getActividades()) {
            // Implementar lógica de clonación profunda si es necesario
            Actividad copiaActividad = copiarActividad(actividad);
            if (copiaActividad != null) {
                clone.agregarActividad(copiaActividad);
            }
        }

        System.out.println("Learning Path clonado: " + clone.getTitulo());
        return clone;
    }

    // metodo para copiar una actividad
    private Actividad copiarActividad(Actividad actividad) {
        if (actividad instanceof Recurso) {
            Recurso recurso = (Recurso) actividad;
            return new Recurso(recurso.getDescripcion(), recurso.getDuracion(), recurso.getNivelDificultad(), recurso.getTipoRecurso(), recurso.getUrl());
        } else if (actividad instanceof Tarea) {
            Tarea tarea = (Tarea) actividad;
            return new Tarea(tarea.getDescripcion(), tarea.getDuracion(), tarea.getNivelDificultad());
        } else if (actividad instanceof Quiz) {
            Quiz quiz = (Quiz) actividad;
            Quiz copiaQuiz = new Quiz(quiz.getDescripcion(), quiz.getDuracion(), quiz.getNivelDificultad());
            for (PreguntaCerrada pregunta : quiz.getPreguntas()) {
                copiaQuiz.agregarPregunta(pregunta);
            }
            return copiaQuiz;
        } else if (actividad instanceof Examen) {
            Examen examen = (Examen) actividad;
            Examen copiaExamen = new Examen(examen.getDescripcion(), examen.getDuracion(), examen.getNivelDificultad());
            for (PreguntaAbierta pregunta : examen.getPreguntas()) {
                copiaExamen.agregarPregunta(pregunta);
            }
            return copiaExamen;
        } else if (actividad instanceof Encuesta) {
            Encuesta encuesta = (Encuesta) actividad;
            Encuesta copiaEncuesta = new Encuesta(encuesta.getDescripcion(), encuesta.getDuracion(), encuesta.getNivelDificultad());
            for (PreguntaAbierta pregunta : encuesta.getPreguntas()) {
                copiaEncuesta.agregarPregunta(pregunta);
            }
            return copiaEncuesta;
        }
        return null;
    }

    // metodo para escribir una reseña sobre un Learning Path
    public void escribirResena(LearningPath learningPath, Resena resena) {
        if (learningPath == null || resena == null) {
            System.out.println("Error: Learning Path o reseña no válidos.");
            return;
        }
        learningPath.agregarResena(resena);
        System.out.println("Reseña añadida al Learning Path: " + learningPath.getTitulo());
    }
}

