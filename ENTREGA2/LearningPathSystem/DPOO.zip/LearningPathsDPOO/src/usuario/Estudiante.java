package usuario;

import learningpath.Actividad;
import learningpath.LearningPath;
import resena.Resena;

public class Estudiante extends Usuario {

    // Constructor
    public Estudiante(String nombre, String apellido, String username, String password) {
        super(nombre, apellido, username, password);
    }

    // Ver la estructura del Learning Path
    public void verEstructuraLearningPath(LearningPath path) {
        if (path == null) {
            System.out.println("Error: Learning Path no válido.");
            return;
        }
        path.mostrarEstructura();
    }

    // Iniciar el Learning Path
    public void iniciarLearningPath(LearningPath path) {
        if (path == null) {
            System.out.println("Error: Learning Path no válido.");
            return;
        }
        System.out.println("Learning Path iniciado: " + path.getTitulo());
    }

    // Iniciar una actividad
    public void iniciarActividad(Actividad actividad) {
        if (actividad == null) {
            System.out.println("Error: Actividad no válida.");
            return;
        }
        System.out.println("Iniciando actividad: " + actividad.getDescripcion());
    }

    // Completar una actividad
    public void completarActividad(Actividad actividad) {
        if (actividad == null) {
            System.out.println("Error: Actividad no válida.");
            return;
        }
        if (!actividad.isCompletada()) {
            actividad.completar();
        } else {
            System.out.println("La actividad " + actividad.getDescripcion() + " ya está completada.");
        }
    }

    // metodo para escribir una reseña sobre un Learning Path
    public void escribirResena(LearningPath path, String contenido, int calificacion) {
        if (path == null) {
            System.out.println("Error: Learning Path no válido.");
            return;
        }
        // Crear una nueva reseña
        Resena resena = new Resena(this, contenido, calificacion);
        // Agregar la reseña al Learning Path
        path.agregarResena(resena);
        System.out.println("Reseña añadida al Learning Path: " + path.getTitulo());
    }
}
