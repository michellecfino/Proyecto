package usuario;
public abstract class Usuario {
    protected String nombre;
    protected String apellido;
    protected String username;
    protected String password;
    protected String correo;

    // Constructor
    public Usuario(String nombre, String apellido, String username, String password) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.username = username;
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (esPasswordValida(password)) {
            this.password = password;
        } else {
            throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres y contener al menos 3 números.");
        }
    }

    private boolean esPasswordValida(String password) {
        if (password.length() < 8) {
            return false;
        }

        int countNumeros = 0;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                countNumeros++;
            }
        }
        return countNumeros >= 3;
    }
}
