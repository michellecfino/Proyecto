package pregunta;
public class PreguntaCerrada {
    private String textoPregunta;
    private String[] opciones; // Opciones de respuesta (ej. A, B, C, D)
    private int indiceRespuestaCorrecta; // Índice de la respuesta correcta

    // Constructor
    public PreguntaCerrada(String textoPregunta, String[] opciones, int indiceRespuestaCorrecta) {
        this.textoPregunta = textoPregunta;
        this.opciones = opciones;
        this.indiceRespuestaCorrecta = indiceRespuestaCorrecta;
    }

    // Método para mostrar la pregunta y sus opciones
    public void mostrarPregunta() {
        System.out.println(textoPregunta);
        for (int i = 0; i < opciones.length; i++) {
            System.out.println((char) ('A' + i) + ") " + opciones[i]);
        }
    }

    // Método para mostrar la respuesta correcta
    public void mostrarRespuestaCorrecta(int respuesta) {
        if (respuesta == indiceRespuestaCorrecta) {
            System.out.println("Respuesta correcta: " + opciones[indiceRespuestaCorrecta]);
        } else {
            System.out.println("Respuesta incorrecta. La correcta era: " + opciones[indiceRespuestaCorrecta]);
        }
    }
}
