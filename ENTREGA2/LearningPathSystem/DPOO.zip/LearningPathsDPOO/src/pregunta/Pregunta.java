package pregunta;
public abstract class Pregunta {
    protected String textoPregunta; // Texto de la pregunta

    // Constructor
    public Pregunta(String textoPregunta) {
        this.textoPregunta = textoPregunta;
    }

    // Obtener el texto de la pregunta
    public String getTextoPregunta() {
        return textoPregunta;
    }

    // Establecer un nuevo texto para la pregunta
    public void setTextoPregunta(String textoPregunta) {
        this.textoPregunta = textoPregunta;
    }

    // Método abstracto para mostrar la pregunta
    public abstract void mostrarPregunta();
}
