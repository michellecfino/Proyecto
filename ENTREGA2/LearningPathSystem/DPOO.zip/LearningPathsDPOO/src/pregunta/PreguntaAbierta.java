package pregunta;

public class PreguntaAbierta extends Pregunta {

    // Constructor
    public PreguntaAbierta(String textoPregunta) {
        super(textoPregunta); 
    }

    // implementacion del metodo abstracto para mostrar la pregunta
    @Override
    public void mostrarPregunta() {
        System.out.println("Pregunta Abierta: " + this.getTextoPregunta());
    } 
}
